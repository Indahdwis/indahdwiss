package com.example.biodata;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void cellphone(View view){
        Uri uri = Uri.parse("tel:088980437307");
        Intent it = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(it);
    }
    public void showmap(View view){
        Uri uri = Uri.parse("geo:-7.05073, 111.02048");
        Intent it = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(it);
    }
    public void email(View view){
        Intent intent = new Intent(Intent.ACTION_SEND);
        Intent.setType("text/plain");
        Intent.putExtra(Intent.EXTRA_EMAIL, new String[] {"indahdwissss117777@gmail.com});
        Intent.putExtra(Intent.EXTRA_SUBJECT, "Email dari aplikasi android");

        try {
            startActivity(Intent.createChooser(Intent,"ingin mengirim email ?"));
        } catch (ActivityNotFoundException ex) {
        }
    }
}