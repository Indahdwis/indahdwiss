<?php
  $nama=$_POST["Indah Dwi Susanti"];
  $email=$_POST["111202012732@mhs.dinus.ac.id"];
  $gender=$_POST["Prempuan"];
  echo "<h1>Halaman Proses Data</h1>";
  echo "Indah Dwi Susanti;$nama dan 111202012732@mhs.dinus.ac.id:$email";
  echo "Prempuan: $gender";
?>