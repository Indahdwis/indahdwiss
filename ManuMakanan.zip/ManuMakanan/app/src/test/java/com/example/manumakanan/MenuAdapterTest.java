package com.example.manumakanan;

import junit.framework.TestCase;

public class MenuAdapterTest extends TestCase {

}