package com.example.manumakanan;

public class Menu {

    public String nama, deskripsi, harga;
    private final int id_gambar;

    public Menu(String nama, String deskripsi, String harga, int id_gambar) {
        this.nama=nama;
        this.deskripsi=deskripsi;
        this.harga=harga;
        this.id_gambar=id_gambar;
    }

    public String getNama() {
        return nama;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public String getHarga() {
        return harga;
    }

    public static int getId_gambar() {
        return id_gambar;
    }
}
