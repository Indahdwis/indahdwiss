package com.example.manumakanan;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Menu> listMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recMenu = findViewById(R.id.rec_MenuMakanan);
        iniData();

        recMenu.setAdapter(new MenuAdapter(listMenu, listMenu));
        recMenu.setLayoutManager(new LinearLayoutManager(this ));
    }

    private void iniData(){
        this.listMenu = new ArrayList<>();
        listMenu.add(new Menu("Pecel Lele",
                "Lele goreng 3 + sambal + lalapan",
                "15.000", R.drawable.pecellele));

        listMenu.add(new Menu("Nasi Goreng Mercon",
                "Nasi goreng mercon spesial dengan tumis cabai dan bawang",
                "14.500", R.drawable.nasgormercon));

        listMenu.add(new Menu("Ayam Geprek Keju",
                "Ayam geprek + keju",
                "20.000", R.drawable.prekju));

        listMenu.add(new Menu("Kari Ayam",
                "Kari ayam",
                "17.500", R.drawable.kariAyam));

        listMenu.add(new Menu("Tahu Bulat",
                "Tahu bulat / biji",
                "500", R.drawable.tahubulat));

        listMenu.add(new Menu("Salat Buah",
                "Salat Buah segar + Topping buah strawberry, kiwi, mangga potong,blueberry",
                "12.500", R.drawable.saladbuah));
    }
}