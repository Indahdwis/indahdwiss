package com.example.manumakanan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Size;
import androidx.recyclerview.widget.RecyclerView;

import java.security.AccessController;
import java.util.ArrayList;




public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.ViewHolder> {

    private ArrayList<Menu> listMenu;

    @NonNull
    @Override
    public MenuAdapter.ViewHolder onCreateViewHolder.ViewHolder,int position) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        ViewHolder holder = new ViewHolder(inflater.inflate(R.layout.menumakanan; parent, false))

        return holder;
    }

    @Override
    public void onBinViewHolder(@NonNull MenuAdapter.ViewHolder holder, int position) {
        Menu menu = listMenu.get(position);
        holder.txtNama.setText(Menu.getNama());
        holder.txtDeskripsi.setText(Menu.getDeskripsi());
        holder.txtHarga.setText(Menu.getHarga());
        holder.imgFoto.setImageResource(Menu.getId_gambar());
    }
    @Override
    public void (){
      return listMenu Size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView txtNama, txtDeskripsi, txtHarga;
        public ImageView imgFoto;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtNama = (TextView) itemView.findViewById(R.id.txtNama);
            txtNama = (TextView) itemView.findViewById(R.id.txtDeskripsi);
            txtNama = (TextView) itemView.findViewById(R.id.txtHarga);
            imgFoto = (ImageView) itemView.findViewById(R.id.imageFoto);
        }
    }
}

